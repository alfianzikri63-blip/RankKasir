RANKMATE KASIR V11 — SUPABASE PROJECT BARU (10.1.1)
==========================================================
Supabase project URL: https://jcmhjmvudpquapzcajfe.supabase.co
Key type: PUBLISHABLE — tidak ada service_role atau Secret Key.

PENTING:
- Project database baru harus sudah dipasang menggunakan file SQL RankMate V11.
- Akun dari project lama TIDAK otomatis tersedia di project baru.
- Buat Admin pada Authentication > Users di PROJECT BARU,
  lalu jalankan file RankMate_02_Aktivasi_Admin.txt sesuai email Admin.
- Setelah upload source, BUILD APK DEBUG terlebih dahulu untuk menguji login.
- APK Debug berbeda ID dengan Release: com.rankmate.reportkasir.debug.
- Versi source diubah ke 10.1.1; APK lama belum otomatis ikut berubah.
- Source Web yang sama juga ada dalam ZIP kedua (untuk website terpisah).
- Untuk verifikasi email dari APK, atur Auth > URL Configuration > Site URL
  ke URL HTTPS website aktif yang Anda kuasai (jangan biarkan localhost).
- RLS (Row Level Security) harus aktif sebelum data produksi dipakai.

Notifikasi update APK:
- Pemeriksa update memakai GitHub Releases: alfianwahyu63-bot/Rankmate-kasir.
- Akan mendeteksi versi di atas 10.1.1, misalnya v10.1.2,
  jika Release memuat asset dengan nama persis rankmate-kasir.apk.
- Notifikasi Android tetap tunduk pada izin dan penjadwalan perangkat.
- Untuk update APK Release tanpa uninstall, gunakan keystore asli yang sama.
- Build Debug TIDAK menandatangani release; jangan didistribusikan sebagai APK resmi.

Kode sumber ini TIDAK berisi password admin atau signing keystore.
