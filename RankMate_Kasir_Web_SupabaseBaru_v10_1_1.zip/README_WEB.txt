RANKMATE WEBSITE MANDIRI V11
============================

Ini paket website saja, tanpa Android atau build APK.

File yang perlu diunggah ke host web: index.html, icon-*.png,
icon-sales.svg, manifest.webmanifest, service-worker.js.

Login tetap menggunakan konfigurasi Supabase yang sudah tertanam
pada index.html V11. Jangan bagikan service_role key (jika ada).

Paket web ini dapat dipasang ke layanan static hosting
(GitHub Pages, Netlify Drop, dsb) setelah file diekstrak.
Pembaruan website tidak mengubah APK Android mandiri yang telah terpasang.
