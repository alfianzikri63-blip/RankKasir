const CACHE='employee-rankmate-supabase-new-v11-1011';
const ASSETS=['./','./index.html','./manifest.webmanifest','./icon-48.png','./icon-180.png','./icon-192.png','./icon-512.png','./icon-sales.svg'];
const SCOPE=new URL(self.registration.scope);
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS)));self.skipWaiting()});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE&&k.startsWith('employee-rankmate')).map(k=>caches.delete(k)))));self.clients.claim()});
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET')return;
 const url=new URL(req.url);
 if(url.origin!==SCOPE.origin||!url.pathname.startsWith(SCOPE.pathname))return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE);
  if(req.mode==='navigate'){
   try{const response=await fetch(req);if(response.ok)await cache.put(req,response.clone());return response}
   catch(e){return await cache.match(req)||await cache.match('./index.html')||Response.error()}
  }
  const cached=await cache.match(req);if(cached)return cached;
  try{const response=await fetch(req);if(response.ok)await cache.put(req,response.clone());return response}
  catch(e){return await cache.match('./index.html')||Response.error()}
 })());
});
