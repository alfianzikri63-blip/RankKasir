package com.rankmate.reportkasir;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.OutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    // Secure HTTPS-like origin for packaged static files (not a public server).
    private static final String LOCAL_HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + LOCAL_HOST + "/assets/web/index.html";
    private static final int FILE_REQUEST = 501;
    private WebView webView;
    private android.webkit.ValueCallback<Uri[]> fileResult;
    private final ExecutorService updateExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean isCheckingUpdate = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff111922);
        getWindow().setNavigationBarColor(0xff111922);
        getWindow().getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(0xff111922);
        setContentView(webView);

        if (Build.VERSION.SDK_INT >= 35) {
            webView.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }
        if (BuildConfig.DEBUG) WebView.setWebContentsDebuggingEnabled(true);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);

        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(LOCAL_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if ("https".equalsIgnoreCase(url.getScheme()) && LOCAL_HOST.equalsIgnoreCase(url.getHost())
                        && url.getPath() != null && url.getPath().startsWith("/assets/web/")) return false;
                // Do not display third-party content inside the privileged WebView.
                try {
                    if ("https".equalsIgnoreCase(url.getScheme()) || "http".equalsIgnoreCase(url.getScheme())) {
                        startActivity(new Intent(Intent.ACTION_VIEW, url));
                    }
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, android.webkit.ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileResult != null) fileResult.onReceiveValue(null);
                fileResult = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQUEST);
                    return true;
                } catch (Exception ignored) {
                    fileResult = null;
                    return false;
                }
            }
        });

        // Only local, bundled RankMate HTML can access this bridge.
        webView.addJavascriptInterface(new RankMateExportBridge(), "RankMateAndroid");
        webView.loadUrl(HOME);
        UpdateJobService.schedule(this);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            mainHandler.postDelayed(() -> {
                if (!isFinishing() && !isDestroyed()) {
                    requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 202);
                }
            }, 900);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Prompt when the APK is opened, even without background notification permission.
        SharedPreferences prefs = getSharedPreferences(UpdateJobService.PREFS, MODE_PRIVATE);
        long now = System.currentTimeMillis();
        if (now - prefs.getLong("last_foreground_check_at", 0) >= 2L * 60 * 60 * 1000) {
            prefs.edit().putLong("last_foreground_check_at", now).apply();
            mainHandler.postDelayed(() -> checkForUpdates(false), 1350);
        }
    }

    private void checkForUpdates(boolean manual) {
        if (isFinishing() || isDestroyed() || updateExecutor.isShutdown()) return;
        if (isCheckingUpdate) {
            if (manual) notice("Pemeriksaan update sedang berjalan");
            return;
        }
        isCheckingUpdate = true;
        updateExecutor.execute(() -> {
            UpdateChecker.Release release = null;
            String error = null;
            try {
                release = UpdateChecker.fetchLatest();
            } catch (Exception e) {
                error = e.getMessage();
            }
            UpdateChecker.Release available = release;
            String failure = error;
            mainHandler.post(() -> {
                isCheckingUpdate = false;
                if (isFinishing() || isDestroyed()) return;
                if (failure != null) {
                    if (manual) notice("Gagal cek update: " + failure);
                    return;
                }
                if (available == null) return;
                if (!UpdateChecker.isNewer(available.version, BuildConfig.VERSION_NAME)) {
                    if (manual) notice("RankMate v" + BuildConfig.VERSION_NAME + " sudah versi terbaru");
                    return;
                }
                SharedPreferences prefs = getSharedPreferences(UpdateJobService.PREFS, MODE_PRIVATE);
                long now = System.currentTimeMillis();
                if (!manual && available.version.equals(prefs.getString("last_prompt_version", ""))
                        && now - prefs.getLong("last_prompt_at", 0) < 24L * 60 * 60 * 1000) {
                    return;
                }
                prefs.edit().putString("last_prompt_version", available.version)
                        .putLong("last_prompt_at", now).apply();
                String message = "Versi terpasang: " + BuildConfig.VERSION_NAME
                        + "\nVersi baru: " + available.version
                        + "\n\nUnduh APK terbaru lewat GitHub Releases."
                        + (available.notes.isEmpty() ? "" : "\n\nCatatan rilis:\n" + available.notes);
                new AlertDialog.Builder(this)
                        .setTitle("Update RankMate tersedia")
                        .setMessage(message)
                        .setPositiveButton("Unduh Update", (dialog, which) -> {
                            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(available.downloadUrl))); }
                            catch (ActivityNotFoundException e) { notice("Browser tidak tersedia"); }
                        })
                        .setNegativeButton("Nanti saja", null)
                        .show();
            });
        });
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == FILE_REQUEST && fileResult != null) {
            fileResult.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result, data));
            fileResult = null;
        }
    }

    private void notice(String message) {
        new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show());
    }

    private class RankMateExportBridge {
        @JavascriptInterface
        public void checkForUpdates() {
            runOnUiThread(() -> MainActivity.this.checkForUpdates(true));
        }

        @JavascriptInterface
        public String installedVersion() {
            return BuildConfig.VERSION_NAME + (BuildConfig.DEBUG ? " DEBUG" : "");
        }

        @JavascriptInterface
        public void saveBase64(String filename, String mimeType, String contentBase64) {
            Uri uri = null;
            try {
                if (contentBase64 == null || contentBase64.length() > 50000000) throw new IllegalArgumentException("File terlalu besar");
                String safe = filename == null ? "RankMate-export" : filename.replaceAll("[^a-zA-Z0-9._-]", "_");
                if (safe.length() == 0) safe = "RankMate-export";
                if (safe.length() > 110) safe = safe.substring(0, 110);
                String mime = (mimeType != null && mimeType.matches("[a-zA-Z0-9.+-]+/[a-zA-Z0-9.+-]+"))
                        ? mimeType : "application/octet-stream";
                byte[] bytes = Base64.decode(contentBase64, Base64.DEFAULT);
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                values.put(MediaStore.Downloads.MIME_TYPE, mime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/RankMate/");
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Tidak dapat membuka folder Downloads");
                try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
                    if (stream == null) throw new IllegalStateException("Tidak dapat menulis file");
                    stream.write(bytes);
                }
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
                notice("File tersimpan di Download/RankMate/" + safe);
            } catch (Exception e) {
                if (uri != null) try { getContentResolver().delete(uri, null, null); } catch (Exception ignored) { }
                notice("Ekspor gagal: " + e.getMessage());
            }
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (fileResult != null) { fileResult.onReceiveValue(null); fileResult = null; }
        if (webView != null) webView.destroy();
        updateExecutor.shutdownNow();
        super.onDestroy();
    }
}
