package com.rankmate.reportkasir;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;

/** Background update check: Android schedules a periodic check approximately every 6 hours. */
public class UpdateJobService extends JobService {
    private static final int JOB_ID = 10029;
    private static final int NOTIFICATION_ID = 10030;
    private static final String CHANNEL_ID = "rankmate_apk_update";
    static final String PREFS = "rankmate_update_state";

    static void schedule(Context context) {
        JobScheduler scheduler = (JobScheduler) context.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if (scheduler == null || scheduler.getPendingJob(JOB_ID) != null) return;
        JobInfo info = new JobInfo.Builder(JOB_ID, new ComponentName(context, UpdateJobService.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setPeriodic(6L * 60 * 60 * 1000)
                .build();
        scheduler.schedule(info);
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        Thread t = new Thread(() -> {
            try {
                UpdateChecker.Release release = UpdateChecker.fetchLatest();
                if (UpdateChecker.isNewer(release.version, BuildConfig.VERSION_NAME)) {
                    SharedPreferences prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                    if (!release.version.equals(prefs.getString("last_notification_version", ""))) {
                        if (showNotification(release)) {
                            prefs.edit().putString("last_notification_version", release.version).apply();
                        }
                    }
                }
            } catch (Exception ignored) {
                // No spam while offline or while a GitHub release hasn't been published yet.
            } finally {
                jobFinished(params, false);
            }
        }, "RankMate-update-background");
        t.start();
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        // Reschedule if Android interrupts the network operation.
        return true;
    }

    private boolean showNotification(UpdateChecker.Release release) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) return false;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return false;
        nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "Update RankMate",
                NotificationManager.IMPORTANCE_DEFAULT));
        Intent browser = new Intent(Intent.ACTION_VIEW, Uri.parse(release.downloadUrl));
        browser.addCategory(Intent.CATEGORY_BROWSABLE);
        PendingIntent open = PendingIntent.getActivity(this, 0, browser,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Update RankMate v" + release.version + " tersedia")
                .setContentText("Ketuk untuk unduh APK terbaru dari GitHub")
                .setStyle(new Notification.BigTextStyle().bigText(
                        "Versi " + release.version + " tersedia. Ketuk untuk mengunduh dan memasang pembaruan."))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build();
        nm.notify(NOTIFICATION_ID, notification);
        return true;
    }
}
