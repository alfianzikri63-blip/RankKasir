package com.rankmate.reportkasir;

import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;

/** Update metadata always comes from a published release with an attached APK. */
final class UpdateChecker {
    private static final String RELEASES_API =
            "https://api.github.com/repos/alfianwahyu63-bot/Rankmate-kasir/releases/latest";
    private static final String EXPECTED_APK = "rankmate-kasir.apk";
    private static final String RELEASE_PATH_PREFIX =
            "/alfianwahyu63-bot/Rankmate-kasir/releases/download/";
    private static final Pattern SEMVER = Pattern.compile("\\d+\\.\\d+\\.\\d+");

    private UpdateChecker() { }

    static final class Release {
        final String version;
        final String downloadUrl;
        final String notes;

        Release(String version, String downloadUrl, String notes) {
            this.version = version;
            this.downloadUrl = downloadUrl;
            this.notes = notes;
        }
    }

    static Release fetchLatest() throws IOException, JSONException {
        HttpURLConnection conn = (HttpURLConnection) new URL(RELEASES_API).openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("Accept", "application/vnd.github+json");
        conn.setRequestProperty("User-Agent", "RankMate-Kasir-Android");
        try {
            int status = conn.getResponseCode();
            if (status == 404) throw new IOException("Rilis APK belum tersedia di GitHub Releases");
            if (status != 200) throw new IOException("GitHub API HTTP " + status);

            JSONObject release = new JSONObject(readLimited(conn.getInputStream()));
            if (release.optBoolean("draft", false) || release.optBoolean("prerelease", false)) {
                throw new IOException("Rilis terbaru belum dipublikasikan");
            }
            String tag = release.optString("tag_name", "");
            String version = tag.startsWith("v") ? tag.substring(1) : tag;
            if (!SEMVER.matcher(version).matches()) throw new IOException("Format tag versi GitHub tidak valid");
            JSONArray assets = release.optJSONArray("assets");
            if (assets == null) throw new IOException("Rilis GitHub belum memiliki file APK");
            for (int i = 0; i < assets.length(); i++) {
                JSONObject asset = assets.optJSONObject(i);
                if (asset == null || !EXPECTED_APK.equals(asset.optString("name"))) continue;
                String url = asset.optString("browser_download_url", "");
                Uri u = Uri.parse(url);
                if (!"https".equalsIgnoreCase(u.getScheme())
                        || !"github.com".equalsIgnoreCase(u.getHost())
                        || u.getPath() == null || !u.getPath().startsWith(RELEASE_PATH_PREFIX)) {
                    throw new IOException("Alamat unduhan APK tidak valid");
                }
                String notes = release.optString("body", "").trim();
                if (notes.length() > 400) notes = notes.substring(0, 400) + "…";
                return new Release(version, url, notes);
            }
            throw new IOException("Rilis terbaru belum menyertakan " + EXPECTED_APK);
        } finally {
            conn.disconnect();
        }
    }

    static boolean isNewer(String available, String installed) {
        if (!SEMVER.matcher(available).matches() || !SEMVER.matcher(installed).matches()) return false;
        String[] a = available.split("\\.");
        String[] b = installed.split("\\.");
        for (int i = 0; i < 3; i++) {
            try {
                int x = Integer.parseInt(a[i]);
                int y = Integer.parseInt(b[i]);
                if (x != y) return x > y;
            } catch (NumberFormatException ignored) {
                return false;
            }
        }
        return false;
    }

    private static String readLimited(InputStream in) throws IOException {
        try (InputStream stream = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096];
            int n, total = 0;
            while ((n = stream.read(b)) != -1) {
                total += n;
                if (total > 256 * 1024) throw new IOException("Respons GitHub terlalu besar");
                out.write(b, 0, n);
            }
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
}
