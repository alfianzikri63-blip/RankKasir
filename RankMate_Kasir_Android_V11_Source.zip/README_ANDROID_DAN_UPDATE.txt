RANKMATE KASIR ANDROID V11 — SOURCE MANDIRI
===========================================

Target APK Debug: app-debug.apk
Versi source: 10.1.0
App ID Debug: com.rankmate.reportkasir.debug
App ID Release: com.rankmate.reportkasir

SOURCE WEB SUDAH DITANAM:
  app/src/main/assets/web/index.html
Login multiuser / Supabase tetap memakai konfigurasi di source V11 ini.
Tidak perlu clone GitHub ataupun mengambil file website dari folder lain.

PEMBARUAN APK:
- UpdateChecker.java mengakses GitHub Releases publik:
  alfianwahyu63-bot/Rankmate-kasir
- Pembaruan terdeteksi hanya jika versi tag lebih tinggi dari APK terpasang
  DAN rilis terbaru (bukan draft/prerelease) memuat 'rankmate-kasir.apk'.
- Saat aplikasi dibuka: cek update otomatis (maksimal sekali per 2 jam).
- Di latar belakang: pemeriksaan berkala sekitar 6 jam, bergantung Android.
- Jika ditemukan: dialog pembaruan dan notifikasi sistem (bila diizinkan).
  Tombol 'Cek Update APK' juga ada di dalam aplikasi.
- Notifikasi membuka halaman unduhan APK; pemasangan tetap perlu disetujui pengguna.
- Tidak menggunakan push real-time; release mungkin tidak langsung terdeteksi.
- APK Debug sengaja memakai ID terpisah supaya bisa dipasang bersamaan dengan Release.
  Data lokal Debug dan Release tidak otomatis saling berpindah.

PENTING SAAT MENCOBA RELEASE BERIKUTNYA:
- Upload APK signed di Releases repo yang sesuai, filename 'rankmate-kasir.apk'.
- Jika versi terpasang 10.1.0, rilis selanjutnya misalnya v10.1.1.
- Untuk update Release tanpa uninstall, tanda tangan keystore harus tetap sama.
- GitHub Releases repo harus bisa diakses publik dari HP pengguna.
- Jangan mengunggah file .jks atau password ke GitHub.

ALUR BUILD DEBUG LEWAT GITHUB:
1. Upload ZIP source ini ke ROOT repository GitHub (jangan ekstrak).
2. Upload workflow rankmate-debug.yml ke .github/workflows/ di repository.
3. Workflow dengan pemicu push akan mengekstrak ZIP source secara otomatis
   lalu membangun Gradle :app:assembleDebug.
4. Unduh artifact RankMate-Kasir-Debug di halaman run Actions yang sukses.
5. Jika GitHub tetap 0 workflow runs, bukan APK yang gagal dibangun:
   artinya workflow belum dipicu / belum diterima GitHub.

Tidak ada APK Release dalam paket ini.
